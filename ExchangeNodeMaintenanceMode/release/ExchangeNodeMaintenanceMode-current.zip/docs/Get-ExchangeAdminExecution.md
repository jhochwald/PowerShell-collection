﻿---
external help file: ExchangeNodeMaintenanceMode-help.xml
online version: 
schema: 2.0.0
---

# Get-ExchangeAdminExecution

## SYNOPSIS
Just a neat function to check if we are elevated

## SYNTAX

```
Get-ExchangeAdminExecution
```

## DESCRIPTION
Just a neat function to check if we are elevated

## EXAMPLES

### -------------------------- EXAMPLE 1 --------------------------
```
# Good case
```

PS \> Get-ExchangeAdminExecution

### -------------------------- EXAMPLE 2 --------------------------
```
# Bad case
```

PS \> Get-ExchangeAdminExecution

Error: You need to start the PowerShell session as Admin (Elevated)

## PARAMETERS

## INPUTS

## OUTPUTS

## NOTES
Just an internal function.

## RELATED LINKS

